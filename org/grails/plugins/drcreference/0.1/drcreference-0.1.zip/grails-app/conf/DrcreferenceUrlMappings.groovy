class DrcreferenceUrlMappings {

  static mappings = {
    "/$controller/$action?/$id?(.$format)?"{ 
      constraints { 
        // apply constraints here
      }
    }

    "/"(view:"/index")
    "500"(view:'/error')

    "/v1/reference/$reference/$word/$fuzzyLimit?" (controller:"reference") { action = [GET: "lookupReference"]}
  }
}
