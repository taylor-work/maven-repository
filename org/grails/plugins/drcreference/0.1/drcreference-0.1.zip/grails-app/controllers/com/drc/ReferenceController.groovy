package com.drc

import grails.converters.JSON
import org.codehaus.groovy.grails.web.json.JSONObject

class ReferenceController {

  def referenceService

  def lookupReference() {
    
    log.debug("$params.reference lookup for word: $params.word")

    if (!params.reference || !params.word) {
      custRespond(200, new JSONObject(warning:'please provide a reference and lookup word'))
    } else {
      def refs = JSON.parse(referenceService.getReference(params))
      
      if (refs.defs.size() == 0)
        custRespond(200,
          new JSONObject(
            warning:"no references found in $params.reference for $params.word", 
            reference:params.reference, 
            word:params.word))
      else
        custRespond(200, refs)
    }
  }

  private def custRespond(status, content) {
    response.status = status
    render(contentType: "text/json") {content}
  }
}
