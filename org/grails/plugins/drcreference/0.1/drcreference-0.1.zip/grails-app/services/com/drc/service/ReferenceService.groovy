package com.drc.service

import grails.util.Holders
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

import com.drc.ref.Ref

class ReferenceService {
  //grails.plugin.searchable.SearchableService
  def searchableService

  def getReference(params) {
    def slurp = new JsonSlurper()
    JsonBuilder builder = new JsonBuilder()
    List refs = query(params)

    def root = builder {
      defs(
          refs.collect { Ref r -> [word: r.word, value: slurp.parseText(r.referenceValue.replace("\\", "\\\\"))] }
      )
    }

    builder.toString()
  }

  def query(params) {
    def ds = (Holders.config.drcreference?.ds) ? Holders.config.drcreference?.ds : 'default' 
    def searchResult = Ref."$ds".findAllByReferenceAndWord(params.reference, params.word)

    if (searchResult == [] && params.fuzzyLimit) {
      def search = "reference:$params.reference ${params.word.replaceAll(" ", "~ ")}~"
      searchResult = searchableService.search(search.toString(), [defaultProperty: "word", max: params.fuzzyLimit]).results
    }

    searchResult
  }
}
