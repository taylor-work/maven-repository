package com.drc.ref

import grails.util.Holders


class Ref {

  static searchable = true
  
  static mapping = {
    datasource 'drcreference'
    table 'REFERENCE'
    reference column: 'REFERENCE'
    word column: 'WORD'
    referenceValue column: 'REFERENCEVALUE'
  }
  
  static constraints = {
    referenceValue maxSize: Integer.MAX_VALUE
  }
  
  String reference
  String word
  String referenceValue
}
