package com.drc.ref

import grails.util.Holders


class Ref {

  static searchable = true
  
  static mapping = {
    def ds = (Holders.config.drcreference?.ds) ? Holders.config.drcreference?.ds : 'DEFAULT'
    datasource ds
    table 'REFERENCE'
    reference column: 'REFERENCE'
    word column: 'WORD'
    referenceValue column: 'REFERENCEVALUE'
  }
  
  static constraints = {
    referenceValue maxSize: Integer.MAX_VALUE
  }
  
  String reference
  String word
  String referenceValue
}
