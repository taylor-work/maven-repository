package com.drc.ref


class Ref {

  static searchable = true
  
  static mapping = {
    table 'REFERENCE'
    reference column: 'REFERENCE'
    word column: 'WORD'
    referenceValue column: 'REFERENCEVALUE'
  }
  
  static constraints = {
    referenceValue maxSize: Integer.MAX_VALUE
  }
  
  String reference
  String word
  String referenceValue
}
